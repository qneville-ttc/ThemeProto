/* Theme specific javascript */

$(document).ready(function() {

	alert("HI");

});