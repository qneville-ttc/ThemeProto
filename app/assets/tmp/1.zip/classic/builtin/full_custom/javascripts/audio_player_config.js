AudioPlayer.setup('/javascripts/flash/player.swf', {
  width: '100%',
  bg: 'E5E5E5',
  leftbg: 'CCCCCC',
  lefticon: '333333',
  voltrack: 'F2F2F2',
  volslider: '666666',
  rightbg: 'B4B4B4',
  rightbghover: '999999',
  righticon: '333333',
  righticonhover: 'FFFFFF',
  loader: '009900',
  track: 'FFFFFF',
  tracker: 'DDDDDD',
  border: 'CCCCCC',
  skip: '666666',
  text: '333333'
});